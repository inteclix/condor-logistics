import React from "react";

class Sidebar extends React.Component {
  render() {
    return (
      <div classNAme="sidebar">
        <ul />
      </div>
    );
  }
}

export default Sidebar;
