import React from "react";

export default class Marchandises extends React.Component {
  render() {
    return (
      <div className="page">
        <div className="content" />
      </div>
    );
  }
}
